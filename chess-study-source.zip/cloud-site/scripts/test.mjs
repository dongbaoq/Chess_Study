import assert from 'node:assert/strict';
import worker from '../dist/server/index.js';

class MockD1 {
  constructor(){this.rows=new Map()}
  prepare(sql){const db=this;return {bind(...params){return {
    async first(){const row=db.rows.get(params[0]);return row ? {revision:row.revision,document:row.document} : null},
    async run(){
      if(sql.startsWith('INSERT')){const [user,document]=params;if(db.rows.has(user))return {meta:{changes:0}};db.rows.set(user,{revision:1,document});return {meta:{changes:1}}}
      const [document,,user,revision]=params;const row=db.rows.get(user);if(!row||row.revision!==revision)return {meta:{changes:0}};db.rows.set(user,{revision:revision+1,document});return {meta:{changes:1}}
    }
  }}}}
}
const db=new MockD1(), env={DB:db};
const request=(method='GET',user='one',body,origin='https://study.example')=>new Request('https://study.example/api/sync',{method,headers:{...(user?{'oai-authenticated-user-id':user}:{}),...(method==='PUT'?{'origin':origin,'content-type':'application/json'}:{})},...(body===undefined?{}:{body:JSON.stringify(body)})});
const call=async(...args)=>{const r=await worker.fetch(request(...args),env);return {status:r.status,body:await r.json()}};
assert.equal((await call('GET','')).status,401);
assert.deepEqual((await call()).body,{revision:0,data:null});
assert.equal((await call('PUT','one',{revision:0,data:{folders:[{id:'x'}]}})).body.revision,1);
assert.deepEqual((await call()).body,{revision:1,data:{folders:[{id:'x'}]}});
assert.equal((await call('GET','two')).body.revision,0);
assert.equal((await call('PUT','one',{revision:0,data:{folders:[]}})).status,409);
assert.equal((await call('PUT','one',{revision:1,data:{folders:[]}},'https://other.example')).status,403);
assert.equal((await call('PUT','one',{revision:1,data:{folders:[]}})).body.revision,2);
assert.equal((await call('PUT','one',{revision:1,data:{folders:[]}})).status,409);
assert.equal((await call('PUT','one',{revision:2,data:[]})).status,400);
assert.equal((await call('PUT','one',{revision:2,data:{large:'x'.repeat(1024*1024)}})).status,413);
assert.match(await (await worker.fetch(new Request('https://study.example/'),env)).text(),/Opening Notebook/);
console.log('Cloud API checks passed: identity, isolation, optimistic conflicts, request validation and page delivery.');
