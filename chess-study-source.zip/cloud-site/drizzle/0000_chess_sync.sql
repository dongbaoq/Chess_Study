CREATE TABLE `chess_sync` (
  `user_id` text PRIMARY KEY NOT NULL,
  `revision` integer NOT NULL,
  `document` text NOT NULL,
  `updated_at` integer NOT NULL
);
