// APP_HTML is supplied by the build script from the current standalone demo.
const APP_HTML = __APP_HTML__;
const MAX_BYTES = 1024 * 1024;
const headers = { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store', 'x-content-type-options': 'nosniff' };
const json = (value, status = 200) => new Response(JSON.stringify(value), { status, headers });

async function sync(request, env) {
  // Sites injects this header after authenticating the visitor. This worker is
  // intended for a Sites deployment and must not be exposed behind a proxy that
  // allows clients to spoof the authenticated identity header.
  const user = request.headers.get('oai-authenticated-user-id');
  if (!user) return json({ error: 'Sign in to synchronize your study.' }, 401);
  if (!env.DB) return json({ error: 'Cloud storage is unavailable.' }, 503);
  if (request.method === 'GET') {
    const row = await env.DB.prepare('SELECT revision, document FROM chess_sync WHERE user_id = ?').bind(user).first();
    if (!row) return json({ revision: 0, data: null });
    try { return json({ revision: row.revision, data: JSON.parse(row.document) }); }
    catch { return json({ error: 'The saved document could not be read.' }, 500); }
  }
  if (request.method !== 'PUT') return json({ error: 'Method not allowed.' }, 405);
  const origin = request.headers.get('origin');
  if (origin !== new URL(request.url).origin) return json({ error: 'Origin not allowed.' }, 403);
  if (!(request.headers.get('content-type') || '').toLowerCase().startsWith('application/json')) return json({ error: 'Expected JSON.' }, 415);
  const length = Number(request.headers.get('content-length'));
  if (Number.isFinite(length) && length > MAX_BYTES) return json({ error: 'The library is too large to sync.' }, 413);
  let body;
  try {
    const bytes = await request.arrayBuffer();
    if (bytes.byteLength > MAX_BYTES) return json({ error: 'The library is too large to sync.' }, 413);
    body = JSON.parse(new TextDecoder().decode(bytes));
  } catch { return json({ error: 'Invalid JSON.' }, 400); }
  if (!body || !Number.isSafeInteger(body.revision) || body.revision < 0 || body.revision >= Number.MAX_SAFE_INTEGER || !body.data || typeof body.data !== 'object' || Array.isArray(body.data)) return json({ error: 'Invalid sync document.' }, 400);
  const document = JSON.stringify(body.data), now = Date.now();
  let result;
  if (body.revision === 0) {
    result = await env.DB.prepare('INSERT INTO chess_sync (user_id, revision, document, updated_at) VALUES (?, 1, ?, ?) ON CONFLICT(user_id) DO NOTHING').bind(user, document, now).run();
  } else {
    result = await env.DB.prepare('UPDATE chess_sync SET revision = revision + 1, document = ?, updated_at = ? WHERE user_id = ? AND revision = ?').bind(document, now, user, body.revision).run();
  }
  if (result.meta.changes !== 1) {
    const current = await env.DB.prepare('SELECT revision FROM chess_sync WHERE user_id = ?').bind(user).first();
    return json({ error: 'The cloud copy changed on another device.', revision: current?.revision ?? 0 }, 409);
  }
  return json({ revision: body.revision + 1 });
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname === '/api/sync') {
      try { return await sync(request, env); }
      catch { return json({ error: 'Cloud synchronization is unavailable.' }, 500); }
    }
    if (url.pathname === '/' && request.method === 'GET') return new Response(APP_HTML, { headers: { 'content-type': 'text/html; charset=utf-8', 'cache-control': 'no-cache', 'x-content-type-options': 'nosniff' } });
    return new Response('Not found', { status: 404, headers: { 'cache-control': 'no-store' } });
  }
};
